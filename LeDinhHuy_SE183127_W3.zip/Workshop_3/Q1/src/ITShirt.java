/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public interface ITShirt {
    int f1 (TShirt[] t);
    void f2 (TShirt[] t);
    void f3 (TShirt[] t);
}
